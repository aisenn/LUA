make
./labyrinth "fileName"